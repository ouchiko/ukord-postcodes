CREATE TABLE `Streets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  `centx` int(11) DEFAULT NULL,
  `centy` int(11) DEFAULT NULL,
  `minx` int(11) DEFAULT NULL,
  `miny` int(11) DEFAULT NULL,
  `maxx` int(11) DEFAULT NULL,
  `maxy` int(11) DEFAULT NULL,
  `settlement` varchar(50) DEFAULT NULL,
  `locality` varchar(50) DEFAULT NULL,
  `cou_unit` varchar(50) DEFAULT NULL,
  `localauth` varchar(50) DEFAULT NULL,
  `til10k` varchar(11) DEFAULT NULL,
  `tile25k` varchar(25) DEFAULT NULL,
  `source` varchar(25) DEFAULT NULL,
  `cent_lat` double DEFAULT NULL,
  `cent_lon` double DEFAULT NULL,
  `min_lat` double DEFAULT NULL,
  `min_lon` double DEFAULT NULL,
  `max_lat` double DEFAULT NULL,
  `max_lon` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name_index` (`name`),
  KEY `class_index` (`classification`),
  KEY `cent_index` (`centx`,`centy`),
  KEY `min_index` (`minx`,`miny`,`maxx`,`maxy`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `AreaCodes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `core_type` char(3) DEFAULT NULL,
  `core_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `key_area_core` (`core_type`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

CREATE TABLE `Areas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `area_name` varchar(254) DEFAULT NULL,
  `area_code` varchar(25) DEFAULT NULL,
  `core_type` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_code_index` (`area_code`),
  KEY `area_core_index` (`core_type`)
) ENGINE=MyISAM AUTO_INCREMENT=9145 DEFAULT CHARSET=latin1;

CREATE TABLE `Postcodes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `postcode` varchar(10) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `easting` int(11) DEFAULT NULL,
  `northing` int(11) DEFAULT NULL,
  `country_code` varchar(11) DEFAULT NULL,
  `nhs_region_ha_code` varchar(11) DEFAULT NULL,
  `nhs_ha_code` varchar(11) DEFAULT NULL,
  `admin_county_code` varchar(11) DEFAULT NULL,
  `admin_district_code` varchar(11) DEFAULT NULL,
  `admin_ward_code` varchar(11) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `formatted` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `postcode_key` (`postcode`),
  KEY `coordinatesh` (`easting`,`northing`),
  KEY `latlon` (`latitude`,`longitude`)
) ENGINE=MyISAM AUTO_INCREMENT=451551 DEFAULT CHARSET=latin1;
